import 'package:flutter/material.dart';
import '../presentation/splash_screen/splash_screen.dart';
import '../presentation/login_screen/login_screen.dart';
import '../presentation/home_feed/home_feed.dart';
import '../presentation/search/search.dart';
import '../presentation/now_playing/now_playing.dart';
import '../presentation/music_library/music_library.dart';

class AppRoutes {
  // TODO: Add your routes here
  static const String initial = '/';
  static const String splashScreen = '/splash-screen';
  static const String loginScreen = '/login-screen';
  static const String homeFeed = '/home-feed';
  static const String search = '/search';
  static const String nowPlaying = '/now-playing';
  static const String musicLibrary = '/music-library';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const SplashScreen(),
    splashScreen: (context) => const SplashScreen(),
    loginScreen: (context) => const LoginScreen(),
    homeFeed: (context) => const HomeFeed(),
    search: (context) => const Search(),
    nowPlaying: (context) => const NowPlaying(),
    musicLibrary: (context) => const MusicLibrary(),
    // TODO: Add your other routes here
  };
}
