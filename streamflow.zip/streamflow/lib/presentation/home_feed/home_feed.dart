import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/mini_player_widget.dart';
import './widgets/music_carousel_widget.dart';
import './widgets/quick_play_widget.dart';

class HomeFeed extends StatefulWidget {
  const HomeFeed({super.key});

  @override
  State<HomeFeed> createState() => _HomeFeedState();
}

class _HomeFeedState extends State<HomeFeed> with TickerProviderStateMixin {
  final ScrollController _scrollController = ScrollController();
  bool _isRefreshing = false;
  int _currentBottomNavIndex = 0;

  // Mock data for music recommendations
  final List<Map<String, dynamic>> recentlyPlayed = [
    {
      "id": 1,
      "title": "Liked Songs",
      "artist": "Your favorite tracks",
      "coverUrl":
          "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop",
      "type": "playlist",
      "trackCount": 127
    },
    {
      "id": 2,
      "title": "Midnight Vibes",
      "artist": "Chill Electronic Mix",
      "coverUrl":
          "https://images.unsplash.com/photo-1571330735066-03aaa9429d89?w=300&h=300&fit=crop",
      "type": "playlist",
      "trackCount": 45
    },
    {
      "id": 3,
      "title": "Golden Hour",
      "artist": "Kacey Musgraves",
      "coverUrl":
          "https://images.unsplash.com/photo-1516280440614-37939bbacd81?w=300&h=300&fit=crop",
      "type": "album",
      "trackCount": 13
    },
    {
      "id": 4,
      "title": "Indie Rock Essentials",
      "artist": "Curated Playlist",
      "coverUrl":
          "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop",
      "type": "playlist",
      "trackCount": 89
    }
  ];

  final List<Map<String, dynamic>> recommendedForYou = [
    {
      "id": 5,
      "title": "Blinding Lights",
      "artist": "The Weeknd",
      "coverUrl":
          "https://images.unsplash.com/photo-1571330735066-03aaa9429d89?w=300&h=300&fit=crop",
      "type": "single",
      "trackCount": 1
    },
    {
      "id": 6,
      "title": "Future Nostalgia",
      "artist": "Dua Lipa",
      "coverUrl":
          "https://images.unsplash.com/photo-1516280440614-37939bbacd81?w=300&h=300&fit=crop",
      "type": "album",
      "trackCount": 11
    },
    {
      "id": 7,
      "title": "Lo-Fi Study Beats",
      "artist": "Focus Music",
      "coverUrl":
          "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop",
      "type": "playlist",
      "trackCount": 156
    },
    {
      "id": 8,
      "title": "Positions",
      "artist": "Ariana Grande",
      "coverUrl":
          "https://images.unsplash.com/photo-1571330735066-03aaa9429d89?w=300&h=300&fit=crop",
      "type": "album",
      "trackCount": 14
    }
  ];

  final List<Map<String, dynamic>> newReleases = [
    {
      "id": 9,
      "title": "Anti-Hero",
      "artist": "Taylor Swift",
      "coverUrl":
          "https://images.unsplash.com/photo-1516280440614-37939bbacd81?w=300&h=300&fit=crop",
      "type": "single",
      "trackCount": 1,
      "releaseDate": "2025-07-10"
    },
    {
      "id": 10,
      "title": "Flowers",
      "artist": "Miley Cyrus",
      "coverUrl":
          "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop",
      "type": "single",
      "trackCount": 1,
      "releaseDate": "2025-07-12"
    },
    {
      "id": 11,
      "title": "SOS",
      "artist": "SZA",
      "coverUrl":
          "https://images.unsplash.com/photo-1571330735066-03aaa9429d89?w=300&h=300&fit=crop",
      "type": "album",
      "trackCount": 23,
      "releaseDate": "2025-07-08"
    },
    {
      "id": 12,
      "title": "As It Was",
      "artist": "Harry Styles",
      "coverUrl":
          "https://images.unsplash.com/photo-1516280440614-37939bbacd81?w=300&h=300&fit=crop",
      "type": "single",
      "trackCount": 1,
      "releaseDate": "2025-07-11"
    }
  ];

  final List<Map<String, dynamic>> trending = [
    {
      "id": 13,
      "title": "Unholy",
      "artist": "Sam Smith ft. Kim Petras",
      "coverUrl":
          "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop",
      "type": "single",
      "trackCount": 1,
      "plays": "2.1M"
    },
    {
      "id": 14,
      "title": "Bad Habit",
      "artist": "Steve Lacy",
      "coverUrl":
          "https://images.unsplash.com/photo-1571330735066-03aaa9429d89?w=300&h=300&fit=crop",
      "type": "single",
      "trackCount": 1,
      "plays": "1.8M"
    },
    {
      "id": 15,
      "title": "Heat Waves",
      "artist": "Glass Animals",
      "coverUrl":
          "https://images.unsplash.com/photo-1516280440614-37939bbacd81?w=300&h=300&fit=crop",
      "type": "single",
      "trackCount": 1,
      "plays": "1.5M"
    },
    {
      "id": 16,
      "title": "About Damn Time",
      "artist": "Lizzo",
      "coverUrl":
          "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop",
      "type": "single",
      "trackCount": 1,
      "plays": "1.3M"
    }
  ];

  final List<Map<String, dynamic>> quickPlayPlaylists = [
    {
      "id": 17,
      "title": "Daily Mix 1",
      "subtitle": "Arctic Monkeys, The Strokes, and more",
      "icon": "shuffle"
    },
    {
      "id": 18,
      "title": "Discover Weekly",
      "subtitle": "Your weekly mixtape of fresh music",
      "icon": "explore"
    },
    {
      "id": 19,
      "title": "Release Radar",
      "subtitle": "Catch all the latest music from artists you follow",
      "icon": "radar"
    }
  ];

  final Map<String, dynamic> currentlyPlaying = {
    "id": 20,
    "title": "Watermelon Sugar",
    "artist": "Harry Styles",
    "coverUrl":
        "https://images.unsplash.com/photo-1516280440614-37939bbacd81?w=300&h=300&fit=crop",
    "isPlaying": true,
    "progress": 0.65
  };

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _handleRefresh() async {
    setState(() {
      _isRefreshing = true;
    });

    // Simulate API call
    await Future.delayed(const Duration(seconds: 2));

    setState(() {
      _isRefreshing = false;
    });
  }

  void _onBottomNavTap(int index) {
    setState(() {
      _currentBottomNavIndex = index;
    });

    switch (index) {
      case 0:
        // Already on Home
        break;
      case 1:
        Navigator.pushNamed(context, '/search');
        break;
      case 2:
        Navigator.pushNamed(context, '/music-library');
        break;
      case 3:
        // Navigate to profile (not implemented)
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Stack(
          children: [
            RefreshIndicator(
              onRefresh: _handleRefresh,
              color: AppTheme.primaryGreen,
              child: CustomScrollView(
                controller: _scrollController,
                physics: const AlwaysScrollableScrollPhysics(),
                slivers: [
                  // Sticky Header
                  SliverAppBar(
                    floating: true,
                    pinned: true,
                    elevation: 0,
                    backgroundColor:
                        AppTheme.lightTheme.scaffoldBackgroundColor,
                    automaticallyImplyLeading: false,
                    expandedHeight: 12.h,
                    flexibleSpace: FlexibleSpaceBar(
                      background: _buildHeader(),
                    ),
                  ),

                  // Main Content
                  SliverToBoxAdapter(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: 2.h),

                        // Recently Played Carousel
                        MusicCarouselWidget(
                          title: "Recently Played",
                          items: recentlyPlayed,
                          onItemTap: _onMusicItemTap,
                          onItemLongPress: _onMusicItemLongPress,
                        ),

                        SizedBox(height: 3.h),

                        // Quick Play Section
                        QuickPlayWidget(
                          playlists: quickPlayPlaylists,
                          onPlaylistTap: _onQuickPlayTap,
                        ),

                        SizedBox(height: 3.h),

                        // Recommended For You Carousel
                        MusicCarouselWidget(
                          title: "Recommended for You",
                          items: recommendedForYou,
                          onItemTap: _onMusicItemTap,
                          onItemLongPress: _onMusicItemLongPress,
                        ),

                        SizedBox(height: 3.h),

                        // New Releases Carousel
                        MusicCarouselWidget(
                          title: "New Releases",
                          items: newReleases,
                          onItemTap: _onMusicItemTap,
                          onItemLongPress: _onMusicItemLongPress,
                        ),

                        SizedBox(height: 3.h),

                        // Trending Carousel
                        MusicCarouselWidget(
                          title: "Trending Now",
                          items: trending,
                          onItemTap: _onMusicItemTap,
                          onItemLongPress: _onMusicItemLongPress,
                        ),

                        SizedBox(
                            height:
                                20.h), // Space for mini player and bottom nav
                      ],
                    ),
                  ),
                ],
              ),
            ),

            // Mini Player
            Positioned(
              bottom: 16.h,
              left: 4.w,
              right: 4.w,
              child: MiniPlayerWidget(
                currentTrack: currentlyPlaying,
                onTap: () => Navigator.pushNamed(context, '/now-playing'),
                onPlayPause: _onPlayPause,
                onNext: _onNext,
              ),
            ),
          ],
        ),
      ),

      // Bottom Navigation
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentBottomNavIndex,
        onTap: _onBottomNavTap,
        type: BottomNavigationBarType.fixed,
        backgroundColor: AppTheme.lightTheme.cardColor,
        selectedItemColor: AppTheme.primaryGreen,
        unselectedItemColor: AppTheme.neutralGray,
        elevation: 8,
        items: [
          BottomNavigationBarItem(
            icon: CustomIconWidget(
              iconName: 'home',
              color: _currentBottomNavIndex == 0
                  ? AppTheme.primaryGreen
                  : AppTheme.neutralGray,
              size: 24,
            ),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: CustomIconWidget(
              iconName: 'search',
              color: _currentBottomNavIndex == 1
                  ? AppTheme.primaryGreen
                  : AppTheme.neutralGray,
              size: 24,
            ),
            label: 'Search',
          ),
          BottomNavigationBarItem(
            icon: CustomIconWidget(
              iconName: 'library_music',
              color: _currentBottomNavIndex == 2
                  ? AppTheme.primaryGreen
                  : AppTheme.neutralGray,
              size: 24,
            ),
            label: 'Library',
          ),
          BottomNavigationBarItem(
            icon: CustomIconWidget(
              iconName: 'person',
              color: _currentBottomNavIndex == 3
                  ? AppTheme.primaryGreen
                  : AppTheme.neutralGray,
              size: 24,
            ),
            label: 'Profile',
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                _getGreeting(),
                style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                  color: AppTheme.neutralGray,
                ),
              ),
              SizedBox(height: 0.5.h),
              Text(
                "Ready to listen?",
                style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          Container(
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.cardColor,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: AppTheme.shadowLight,
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: IconButton(
              onPressed: _onNotificationTap,
              icon: CustomIconWidget(
                iconName: 'notifications',
                color: AppTheme.deepCharcoal,
                size: 24,
              ),
              padding: EdgeInsets.all(2.w),
            ),
          ),
        ],
      ),
    );
  }

  String _getGreeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) {
      return "Good morning";
    } else if (hour < 17) {
      return "Good afternoon";
    } else {
      return "Good evening";
    }
  }

  void _onMusicItemTap(Map<String, dynamic> item) {
    // Navigate to detail view with shared element transition
    // For now, just show a snackbar
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Playing: ${item["title"]} by ${item["artist"]}'),
        backgroundColor: AppTheme.deepCharcoal,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _onMusicItemLongPress(Map<String, dynamic> item) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.lightTheme.cardColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 10.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: AppTheme.neutralGray.withValues(alpha: 0.3),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            SizedBox(height: 3.h),
            Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: CustomImageWidget(
                    imageUrl: item["coverUrl"] as String,
                    width: 15.w,
                    height: 15.w,
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        item["title"] as String,
                        style: AppTheme.lightTheme.textTheme.titleMedium,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      Text(
                        item["artist"] as String,
                        style:
                            AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                          color: AppTheme.neutralGray,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 4.h),
            _buildQuickActionTile(
              icon: 'play_arrow',
              title: 'Play Now',
              onTap: () {
                Navigator.pop(context);
                _onMusicItemTap(item);
              },
            ),
            _buildQuickActionTile(
              icon: 'queue_music',
              title: 'Add to Queue',
              onTap: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Added to queue')),
                );
              },
            ),
            _buildQuickActionTile(
              icon: 'favorite_border',
              title: 'Save to Library',
              onTap: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Saved to library')),
                );
              },
            ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickActionTile({
    required String icon,
    required String title,
    required VoidCallback onTap,
  }) {
    return ListTile(
      leading: CustomIconWidget(
        iconName: icon,
        color: AppTheme.deepCharcoal,
        size: 24,
      ),
      title: Text(
        title,
        style: AppTheme.lightTheme.textTheme.bodyLarge,
      ),
      onTap: onTap,
      contentPadding: EdgeInsets.symmetric(horizontal: 2.w),
    );
  }

  void _onQuickPlayTap(Map<String, dynamic> playlist) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Playing: ${playlist["title"]}'),
        backgroundColor: AppTheme.deepCharcoal,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _onNotificationTap() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('No new notifications'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _onPlayPause() {
    setState(() {
      currentlyPlaying["isPlaying"] = !currentlyPlaying["isPlaying"];
    });
  }

  void _onNext() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Playing next track'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}
