import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class SearchResultItemWidget extends StatelessWidget {
  final String title;
  final String subtitle;
  final String imageUrl;
  final String type;
  final String? duration;
  final VoidCallback onTap;
  final VoidCallback onMoreTap;

  const SearchResultItemWidget({
    super.key,
    required this.title,
    required this.subtitle,
    required this.imageUrl,
    required this.type,
    this.duration,
    required this.onTap,
    required this.onMoreTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 1.h),
        child: Row(
          children: [
            // Image/Avatar
            Container(
              width: 12.w,
              height: 12.w,
              decoration: BoxDecoration(
                borderRadius:
                    BorderRadius.circular(type == 'Artist' ? 6.w : 8.0),
              ),
              child: ClipRRect(
                borderRadius:
                    BorderRadius.circular(type == 'Artist' ? 6.w : 8.0),
                child: CustomImageWidget(
                  imageUrl: imageUrl,
                  width: 12.w,
                  height: 12.w,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            SizedBox(width: 3.w),
            // Content
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: AppTheme.darkTheme.textTheme.bodyLarge?.copyWith(
                      color: AppTheme.textPrimary,
                      fontWeight: FontWeight.w500,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  SizedBox(height: 0.5.h),
                  Row(
                    children: [
                      if (type == 'Song') ...[
                        Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 2.w, vertical: 0.5.h),
                          decoration: BoxDecoration(
                            color: AppTheme.neutralGray.withValues(alpha: 0.2),
                            borderRadius: BorderRadius.circular(4.0),
                          ),
                          child: Text(
                            'E',
                            style: AppTheme.darkTheme.textTheme.labelSmall
                                ?.copyWith(
                              color: AppTheme.textSecondary,
                              fontSize: 8.sp,
                            ),
                          ),
                        ),
                        SizedBox(width: 2.w),
                      ],
                      Expanded(
                        child: Text(
                          subtitle,
                          style:
                              AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                            color: AppTheme.textSecondary,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (duration != null) ...[
                        SizedBox(width: 2.w),
                        Text(
                          duration!,
                          style:
                              AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                            color: AppTheme.textSecondary,
                          ),
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
            // Action Button
            if (type == 'Song') ...[
              SizedBox(width: 2.w),
              GestureDetector(
                onTap: onTap,
                child: Container(
                  padding: EdgeInsets.all(2.w),
                  child: CustomIconWidget(
                    iconName: 'play_arrow',
                    color: AppTheme.textSecondary,
                    size: 6.w,
                  ),
                ),
              ),
            ],
            // More Options
            GestureDetector(
              onTap: onMoreTap,
              child: Container(
                padding: EdgeInsets.all(2.w),
                child: CustomIconWidget(
                  iconName: 'more_vert',
                  color: AppTheme.textSecondary,
                  size: 5.w,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
