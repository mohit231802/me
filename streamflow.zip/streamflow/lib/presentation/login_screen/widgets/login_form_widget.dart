import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class LoginFormWidget extends StatelessWidget {
  final GlobalKey<FormState> formKey;
  final TextEditingController emailController;
  final TextEditingController passwordController;
  final FocusNode emailFocusNode;
  final FocusNode passwordFocusNode;
  final bool isPasswordVisible;
  final String? emailError;
  final String? passwordError;
  final bool isLoading;
  final VoidCallback onPasswordVisibilityToggle;
  final VoidCallback onForgotPassword;

  const LoginFormWidget({
    super.key,
    required this.formKey,
    required this.emailController,
    required this.passwordController,
    required this.emailFocusNode,
    required this.passwordFocusNode,
    required this.isPasswordVisible,
    required this.emailError,
    required this.passwordError,
    required this.isLoading,
    required this.onPasswordVisibilityToggle,
    required this.onForgotPassword,
  });

  @override
  Widget build(BuildContext context) {
    return Form(
      key: formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Email Field
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                decoration: BoxDecoration(
                  color: AppTheme.cardLight,
                  borderRadius: BorderRadius.circular(12),
                  border: emailError != null
                      ? Border.all(color: AppTheme.errorRed, width: 1)
                      : emailFocusNode.hasFocus
                          ? Border.all(color: AppTheme.primaryGreen, width: 2)
                          : null,
                ),
                child: TextFormField(
                  controller: emailController,
                  focusNode: emailFocusNode,
                  enabled: !isLoading,
                  keyboardType: TextInputType.emailAddress,
                  textInputAction: TextInputAction.next,
                  autocorrect: false,
                  enableSuggestions: true,
                  style: AppTheme.lightTheme.textTheme.bodyLarge,
                  decoration: InputDecoration(
                    hintText: 'Email address',
                    prefixIcon: Padding(
                      padding: EdgeInsets.all(3.w),
                      child: CustomIconWidget(
                        iconName: 'email',
                        color: emailFocusNode.hasFocus
                            ? AppTheme.primaryGreen
                            : AppTheme.neutralGray,
                        size: 5.w,
                      ),
                    ),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(
                      horizontal: 4.w,
                      vertical: 2.h,
                    ),
                    hintStyle:
                        AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
                      color: AppTheme.neutralGray,
                    ),
                  ),
                  onFieldSubmitted: (_) {
                    passwordFocusNode.requestFocus();
                  },
                ),
              ),
              if (emailError != null) ...[
                SizedBox(height: 1.h),
                Padding(
                  padding: EdgeInsets.only(left: 2.w),
                  child: Text(
                    emailError!,
                    style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                      color: AppTheme.errorRed,
                    ),
                  ),
                ),
              ],
            ],
          ),

          SizedBox(height: 2.h),

          // Password Field
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                decoration: BoxDecoration(
                  color: AppTheme.cardLight,
                  borderRadius: BorderRadius.circular(12),
                  border: passwordError != null
                      ? Border.all(color: AppTheme.errorRed, width: 1)
                      : passwordFocusNode.hasFocus
                          ? Border.all(color: AppTheme.primaryGreen, width: 2)
                          : null,
                ),
                child: TextFormField(
                  controller: passwordController,
                  focusNode: passwordFocusNode,
                  enabled: !isLoading,
                  obscureText: !isPasswordVisible,
                  textInputAction: TextInputAction.done,
                  style: AppTheme.lightTheme.textTheme.bodyLarge,
                  decoration: InputDecoration(
                    hintText: 'Password',
                    prefixIcon: Padding(
                      padding: EdgeInsets.all(3.w),
                      child: CustomIconWidget(
                        iconName: 'lock',
                        color: passwordFocusNode.hasFocus
                            ? AppTheme.primaryGreen
                            : AppTheme.neutralGray,
                        size: 5.w,
                      ),
                    ),
                    suffixIcon: GestureDetector(
                      onTap: onPasswordVisibilityToggle,
                      child: Padding(
                        padding: EdgeInsets.all(3.w),
                        child: CustomIconWidget(
                          iconName: isPasswordVisible
                              ? 'visibility'
                              : 'visibility_off',
                          color: AppTheme.neutralGray,
                          size: 5.w,
                        ),
                      ),
                    ),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(
                      horizontal: 4.w,
                      vertical: 2.h,
                    ),
                    hintStyle:
                        AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
                      color: AppTheme.neutralGray,
                    ),
                  ),
                ),
              ),
              if (passwordError != null) ...[
                SizedBox(height: 1.h),
                Padding(
                  padding: EdgeInsets.only(left: 2.w),
                  child: Text(
                    passwordError!,
                    style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                      color: AppTheme.errorRed,
                    ),
                  ),
                ),
              ],
            ],
          ),

          SizedBox(height: 1.h),

          // Forgot Password Link
          Align(
            alignment: Alignment.centerRight,
            child: GestureDetector(
              onTap: onForgotPassword,
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 1.h),
                child: Text(
                  'Forgot Password?',
                  style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                    color: AppTheme.primaryGreen,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
